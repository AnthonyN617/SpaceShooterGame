﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DragonflyEnemyController : MonoBehaviour
{

    public float speed = 10f;
    public int hitPoints = 2;
    public float ROF = 0.5f;
    public GameObject enemyBullet;
    public GameObject enemyExplosion;
    GameObject player;
    bool firing;
    Vector2 nextPosition = Vector2.zero;
    bool playerSpotted = false;


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Detector")
        {
            playerSpotted = true;
        }
    }



    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Detector")
        {
            playerSpotted = false;
        }
    }



    void Start()
    {
        StartCoroutine("FindNextPosition");
        player = GameObject.Find("Player");
    }

    // Update is called once per frame

    void Update()
    {
        gameObject.transform.position = Vector3.Lerp(gameObject.transform.position, nextPosition, speed * Time.deltaTime);
        transform.up = -(player.transform.position - transform.position);
        StartCoroutine("Fire");
    }

    public void Hit()
    {
        hitPoints--;

        if (hitPoints == 0)
        {
            Instantiate(enemyExplosion, transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
    }

    IEnumerator Fire()
    {
        if(!firing)
        {
            firing = true;
            float newROF = ROF * Random.Range(0.2f, 2.0f);
            yield return new WaitForSeconds(newROF);
            Instantiate(enemyBullet, transform.position, transform.rotation * Quaternion.Euler (0f, 0f, 180f));
            firing = false;
            
        }
       
    }

    IEnumerator FindNextPosition()
    {

        nextPosition = new Vector2(Random.Range(-7, 7), Random.Range(-4, 4));

        gameObject.transform.rotation = Quaternion.Euler(0, 0, Random.Range(0, 360));

        yield return new WaitForSeconds(3);

        StartCoroutine("FindNextPosition");

    }
}