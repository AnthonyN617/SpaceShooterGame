﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Laser : MonoBehaviour {
    public bool laserFiring = false;
    public LayerMask mask;
    public GameObject miss;
    public GameObject explosion;

    LineRenderer lr;
    


	// Use this for initialization
	void Start () {
        lr = GetComponent<LineRenderer>();
	}
	
	// Update is called once per frame
	void FixedUpdate () {
        if (laserFiring)
        {
            RaycastHit2D hit = Physics2D.Raycast(transform.position, transform.up, Mathf.Infinity, mask);
            Debug.DrawRay(transform.position, transform.up, Color.green);

            lr.SetPosition(0, transform.position);
            lr.SetPosition(1, hit.point);

            lr.enabled = true;

            GameObject hitObj = hit.collider.gameObject;



            if (hitObj.tag == "Enemy")
            {
                Instantiate(explosion, hitObj.transform.position, Quaternion.identity);
                Destroy(hitObj);

            }

            else Instantiate(miss, hit.point, Quaternion.identity);

        }
        else lr.enabled = false;
	}
}
