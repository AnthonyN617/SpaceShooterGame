﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrackPlayer : MonoBehaviour
{
    GameObject player;
    public float speed = 1.0f;
    bool playerSpotted = false;


    
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Detector")
        {
            playerSpotted = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Detector")
        {
            playerSpotted = false;
        }
    }

    public void Update()
    {
        
            player = GameObject.Find("Player");
         
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (playerSpotted == true)
        {
            transform.position = Vector2.Lerp(transform.position, player.transform.position, speed * Time.fixedDeltaTime);
        }
    }
}
