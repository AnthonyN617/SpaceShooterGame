﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WeaponsPrompt : MonoBehaviour
{
    /*GameObject MissilePrompt;
    GameObject LaserPrompt;
    PlayerController playerScript;
    */


    // Use this for initialization
    void Start()
    {
        
    }

    // Update is called once per frame
    /*void Update()
    {
        if (hasMissile = true)
        {
            StartCoroutine("missilePrompt");
        }
    }*/

    /*IEnumerator missilePrompt()
    {
        //display missile prompt
        yield return new WaitForSeconds(5);
    }*/
}