﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    

    public int hitPoints = 3;
    public float ROF = 0.5f;
    public GameObject enemyBullet;
    public GameObject enemyExplosion;
    GameObject player;
    bool firing;
    bool playerSpotted = false;




    private void OnTriggerEnter2D(Collider2D collision)      
    {
        if (collision.gameObject.tag == "Detector")
            {
            playerSpotted = true;
            }
    }



    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Detector")
        {
            playerSpotted = false;
        }
    }


    void Update()
    {
        if (playerSpotted == true)
        {
            player = GameObject.Find("Player");
            transform.up = -(player.transform.position - transform.position);
            StartCoroutine("Fire");
        }
    }

    public void Hit()
    {
        hitPoints--;

        if (hitPoints == 0)
        {
            Instantiate(enemyExplosion, transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
    }

    IEnumerator Fire()
    {
        if(!firing)
        {
            firing = true;
            float newROF = ROF * Random.Range(0.2f, 2.0f);
            yield return new WaitForSeconds(newROF);
            Instantiate(enemyBullet, transform.position, transform.rotation * Quaternion.Euler (0f, 0f, 180f));
            firing = false;
            
        }
       
    }
}