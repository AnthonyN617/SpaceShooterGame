﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpiderEnemyController : MonoBehaviour
{
    public Transform[] bulletSpawners;

    public int hitPoints = 5;
    public float speed = 10f;
    public float ROF = 0.5f;
    public GameObject enemyBullet;
    public GameObject enemyExplosion;
    public bool fire = false;
    
    bool firing;

   
    

    // Use this for initialization
    void Start()
    {
        

    }

    // Update is called once per frame

    void Update()
    {
        

        

    }

    public void Hit()
    {
        hitPoints--;

        if (hitPoints == 0)
        {
            Instantiate(enemyExplosion, transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
    }

    
    public void ShipFire()
    {
        
            
            foreach (Transform bulletSpawner in bulletSpawners)
            {
                Instantiate(enemyBullet, bulletSpawner.position, bulletSpawner.rotation);
            }
                         
    }

}